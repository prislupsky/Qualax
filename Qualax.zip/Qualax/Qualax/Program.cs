﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;

/// <summary>
/// Program as instructed by Qualax for its hiring process.
/// 
/// Create a C# console application that is a simple version of Mastermind.  
/// 
/// 1.Generate a random answer should be four (4) digits in length.
/// 2.Each digit between the numbers 1 and 6.  
/// 
/// After the player enters a combination:
/// 1.Print minus(-) for every digit that is correct but in the wrong position.
/// 2.Print plus(+) sign for every digit that is both correct and in the correct position.
/// 3.Print nothing()blank, b for incorrect digits.  
/// 
/// Set player’s allotted number of guesses to 10 attempts.
/// If guessed correctly within the allotted number of attempts, stop and alert of a win.
/// If the number is NOT guessed correctly after the allotted number of attempts, provide a message that they have lost.
/// 
/// Global parameters / constants are used and can be adjusted if user wishes to alter the:
/// 1.Number of attempts
/// 2.	Number of digits
/// 3.	Largest value for each digit.
/// 
/// Rob Prislupsky
/// 610.509.1375
/// rob.prislupsky@outlook.com
/// </summary>
/// 

class Program
{
    /// <summary>
    /// Adjustable constants
    /// </summary>
    public int numberOfDigsGlobal = 4;  //Number of digits in number combination
    public int maxDigitValGlobal = 6;   //Max value for each digit in string
    public int maxNumTriesGlobal = 10;  //Number of guesses users are allotted before game is finished if no winning guess

    /// <summary>
    /// Game start.
    /// Set name.
    /// </summary>
    static void Main(string[] args)
    {
        try
        {
            string strPlayerName = "";
            do
            {
                Console.Write("Please enter your name: ");
                strPlayerName = Console.ReadLine();
                strPlayerName = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(strPlayerName.ToLower());

            } while (strPlayerName == "");

            Console.WriteLine("Pleased to meet you, {0}. Let's play.\n", strPlayerName);
            string ng = ">>>>>>>>>> New Game, " + strPlayerName;
            do
            {
                Console.WriteLine("\n==============================================================================\n" + ng + "!");
                PlayGuessingGame(strPlayerName);

                Console.Write("\nPlay again (Y/N)? ");
            }
            while (Console.ReadLine().ToUpper() == "Y");
        }
        catch(Exception e)
        {
            Console.WriteLine(e.Message + "\n" + e.StackTrace);
        }
    }

    /// <summary>
    /// Run game process
    /// </summary>
    /// <param name="strPlayerName"></param>
    private static void PlayGuessingGame(string strPlayerName)
    {
        try
        {
            var mc = new Program();

            //Global value of number of digits in number string/combination
            int numberOfDigsCount = mc.numberOfDigsGlobal;

            Console.WriteLine();

            // Get randmom num
            int numVal = GetNums();

            Console.WriteLine("\nHmmmm...I am thinking of a {0} digit number. Please give me a minute, {1}.\n", numberOfDigsCount, strPlayerName);

            int milliseconds = 500;

            //Just a fun visual - No challenge for ChatGPT
            for (int i = 1; i < 10; i++)
            {
                Thread.Sleep(milliseconds);
                Console.Write(" . ");
            }

            //Global value highest value for each individual digit
            int maxDigitVal = mc.maxDigitValGlobal;

            Console.WriteLine("\nOK...Great! I have my {0} digit number in my mind. \nEach of my {1} digits is between 1 and {2}.\n", numberOfDigsCount, numberOfDigsCount, maxDigitVal);

            //Global valuefor number of tries player is allotted
            int maxNumTries = mc.maxNumTriesGlobal;

            bool youwon = false;
            for (int intTries = maxNumTries; intTries > 0 && !youwon; intTries--)
            {
                string prompt = "";
                if (intTries == maxNumTries)
                {
                    prompt = "\nEnter your 1st guess. Good luck!";
                }
                else
                {
                    prompt = "\nEnter guess number " + (maxNumTries + 1 - intTries).ToString() + ". You have " + intTries.ToString() + " guess(es) remaining.";
                }

                Console.WriteLine(prompt);

                string userGuess = GetPlayersGuess();

                if (numVal.ToString() == userGuess)
                {
                    youwon = true;
                    break;
                }
                else
                {
                    DisplayNonCorrectResults(numVal.ToString(), userGuess);
                }
            }

            if (youwon)
                Console.WriteLine("\n\nYou won, {0}!", strPlayerName);
            else
            {
                Console.WriteLine("\n\nSorry, {0}! You didn't guess the correct number.", strPlayerName);
                Console.Write("The correct number is: " + numVal.ToString());
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message + "\n" + e.StackTrace);
        }
    }

    /// <summary>
    /// Generate random number combination
    /// </summary>
    /// <returns></returns>
    public static int GetNums()
    {
        string numstr = "";
        try
        {
            var mc = new Program();

            int numberOfDigsCount = mc.numberOfDigsGlobal;
            int maxDigitVal = mc.maxDigitValGlobal;
            
            Random rnd = new Random();
            for (int i = 1; i <= numberOfDigsCount; i++)
            {
                numstr = numstr + rnd.Next(1, 7).ToString();
            }
            // Console.WriteLine(numstr);  ///For Testing. May need again.

        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message + "\n" + e.StackTrace);
        }
        return Int32.Parse(numstr);
    }

    /// <summary>
    /// Process player guess
    /// </summary>
    /// <returns></returns>
    public static string GetPlayersGuess()
    {
        string locGuess= Console.ReadLine();
        try
        {
            bool guessOK = false;
            while (!guessOK)
            {
                guessOK = CheckNumFormat(locGuess);
                if (!guessOK)
                {
                    Console.Write("Reenter: \n");
                    locGuess = Console.ReadLine();
                }
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message + "\n" + e.StackTrace);
        }

        return locGuess;
    }

    /// <summary>
    /// Verify a valid guess
    /// </summary>
    /// <param name="locGuess"></param>
    /// <returns></returns>

    public static bool CheckNumFormat(string locGuess)
    {
        var mc = new Program();
        int numberOfDigsCount = mc.numberOfDigsGlobal;
        int maxDigitValGlobal = mc.maxDigitValGlobal;

        string errmsg = "";

        bool retval = true;

        try
        {
            ///Number Validation
            if (locGuess.Length != numberOfDigsCount)
            {
                /// Number of digits
                errmsg = errmsg + "\nGuess has incorrect number (" + locGuess.Length + ") of digits.  Must be EXACTLY " + numberOfDigsCount + " valid positive integers ONLY.";
                retval = false;
            }
            if (!int.TryParse(locGuess, out _))
            {
                /// NOT an integer
                errmsg = errmsg + "\nGuess is NOT a valid number.";
                retval = false;
            }
            if (Int32.Parse(locGuess) <= 0)
            {
                /// Not POSITIVE
                errmsg = errmsg + "\nGuess has incorrect scope. Must be POSITIVE integers ONLY.";
                retval = false;
            }

            ///Each digit can only have a provided max value
            foreach (char c in locGuess)
            {
                if (Int32.Parse(c.ToString()) > maxDigitValGlobal || Int32.Parse(c.ToString()) < 1)
                {
                    errmsg = errmsg + "\nGuess must have valid positive integers ONLY form 1 to " + maxDigitValGlobal.ToString();
                    retval = false;
                    break;
                }
            }
            if(errmsg!="") Console.WriteLine(errmsg);
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message + "\n" + e.StackTrace);
        }
        return retval;
    }

    /// <summary>
    /// Based on result of comparison, display directional results
    /// </summary>
    /// <param name="rnum"></param>
    /// <param name="usernum"></param>
    public static void DisplayNonCorrectResults(string rnum, string usernum)
    {
        try
        {
            var mc = new Program();
            int numberOfDigsCount = mc.numberOfDigsGlobal;

            char[] randchars = rnum.ToCharArray();
            char[] userchars = usernum.ToCharArray();
            char[] leftchars = randchars;

            string[] display = new string[numberOfDigsCount];
            for (int i = 0; i < numberOfDigsCount; i++)
            {
                if (userchars[i].ToString() != randchars[i].ToString())
                {
                    if (leftchars.Contains(userchars[i]))
                    {
                        display[i] = "-";
                    }
                    else
                    {
                        display[i] = " ";
                    }

                }
                else
                {
                    if (randchars[i].ToString() == userchars[i].ToString())
                    {
                        display[i] = "+";
                        leftchars[i] = char.Parse("0");
                    }
                }
            }
            string dispToUser = string.Join("", display);
            Console.WriteLine(dispToUser);
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message + "\n" + e.StackTrace);
        }
    }
}